# Smart Invoice Generator — Vibe Coding Assignment

## Purpose
A bilingual English/Norwegian invoice maker for small businesses. Built with HTML, CSS, and vanilla JavaScript, without external dependencies.

## Features
1. Enter company and customer information, invoice dates and payment details.
2. Add/remove multiple line items; calculate line totals, VAT (MVA) and invoice total in NOK.
3. Preview and print the invoice, including Save as PDF via the browser print dialog.
4. Switch between English and Norwegian; save and load one draft in local browser storage.

## Run
Unzip the folder and double-click `index.html` in Chrome, Edge, or Firefox. No installation or internet is required.

## Test
1. Enter company and customer names and addresses.
2. Add two items: 2 × NOK 100 at 25% MVA and 1 × NOK 200 at 0% MVA. Expected subtotal NOK 400, MVA NOK 50, total NOK 450.
3. Change language to Norsk and check labels and totals. Change back to English; entered information should remain.
4. Click Save draft, refresh the page, and click Load draft. Verify that data returns.
5. Click Print / Save as PDF, select 'Save as PDF' as the destination, and check the resulting document.
6. Try printing with no invoice number: a warning should appear.
7. Try a due date earlier than the issue date: a warning should appear.

## How AI was used (example documentation; adjust to reflect your actual process)
- Described the app requirements in natural language.
- Asked AI to generate a responsive interface, bilingual translations, calculation logic, and printable invoice layout.
- Used a manual test checklist to check VAT calculations, switching languages, and PDF printing.

## Important limitations
This is an educational prototype, not a certified accounting or invoicing system. The user enters invoice numbers manually; it does not guarantee consecutive numbering or tamper-proof invoice records. Norwegian invoice compliance, including applicable MVA treatment and invoicing requirements, must be verified before commercial use. Drafts are stored only on the current browser/device, are not encrypted, and may be lost if browser storage is cleared. The app does not send invoices, issue EHF files, or process payments. Printing uses the browser's built-in PDF option rather than a PDF library.
